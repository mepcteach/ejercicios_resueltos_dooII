import javax.swing.*;
import java.awt.*;

public class Ej01Imc extends JFrame {

    private final JTextField txtPeso = new JTextField(8);
    private final JTextField txtAltura = new JTextField(8);
    private final JLabel lblResultado =
            new JLabel("Ingrese sus datos y presione Calcular", SwingConstants.CENTER);

    public Ej01Imc() {
        super("Calculadora de IMC");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel formulario = new JPanel(new GridLayout(2, 2, 10, 10));
        formulario.setBorder(BorderFactory.createEmptyBorder(15, 20, 5, 20));
        formulario.add(new JLabel("Peso (kg):"));
        formulario.add(txtPeso);
        formulario.add(new JLabel("Altura (m):"));
        formulario.add(txtAltura);

        JButton btnCalcular = new JButton("Calcular IMC");
        btnCalcular.addActionListener(e -> calcular());
        JPanel panelBoton = new JPanel();
        panelBoton.add(btnCalcular);

        lblResultado.setFont(lblResultado.getFont().deriveFont(Font.BOLD, 14f));
        lblResultado.setBorder(BorderFactory.createEmptyBorder(5, 20, 15, 20));

        add(formulario, BorderLayout.NORTH);
        add(panelBoton, BorderLayout.CENTER);
        add(lblResultado, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
    }

    private void calcular() {
        try {
            double peso = Double.parseDouble(txtPeso.getText().trim().replace(',', '.'));
            double altura = Double.parseDouble(txtAltura.getText().trim().replace(',', '.'));
            if (peso <= 0 || altura <= 0) {
                throw new NumberFormatException("Valores no positivos");
            }
            double imc = peso / (altura * altura);

            String categoria;
            Color color;
            if (imc < 18.5) {
                categoria = "Bajo peso";
                color = new Color(0, 102, 204);
            } else if (imc < 25) {
                categoria = "Normal";
                color = new Color(0, 140, 0);
            } else if (imc < 30) {
                categoria = "Sobrepeso";
                color = new Color(210, 120, 0);
            } else {
                categoria = "Obesidad";
                color = new Color(190, 0, 0);
            }
            lblResultado.setForeground(color);
            lblResultado.setText(String.format("IMC = %.1f  (%s)", imc, categoria));
        } catch (NumberFormatException ex) {
            lblResultado.setForeground(Color.RED);
            lblResultado.setText("Ingrese números válidos mayores que 0");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ej01Imc().setVisible(true));
    }
}
