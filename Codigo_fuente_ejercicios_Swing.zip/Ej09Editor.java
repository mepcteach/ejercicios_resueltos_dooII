import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class Ej09Editor extends JFrame {

    private final JTextArea areaTexto = new JTextArea();
    private final JLabel lblEstado = new JLabel();
    private File archivoActual = null;

    public Ej09Editor() {
        super("Mini Editor - Sin título");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(560, 380);
        setLocationRelativeTo(null);

        areaTexto.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        areaTexto.setMargin(new Insets(6, 6, 6, 6));
        add(new JScrollPane(areaTexto), BorderLayout.CENTER);
        add(lblEstado, BorderLayout.SOUTH);
        setJMenuBar(crearMenu());

        // Cada cambio en el documento actualiza la barra de estado
        areaTexto.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e)  { actualizarEstado(); }
            public void removeUpdate(DocumentEvent e)  { actualizarEstado(); }
            public void changedUpdate(DocumentEvent e) { actualizarEstado(); }
        });
        actualizarEstado();
    }

    private JMenuBar crearMenu() {
        JMenu mnuArchivo = new JMenu("Archivo");
        mnuArchivo.add(crearItem("Nuevo", KeyEvent.VK_N, e -> nuevo()));
        mnuArchivo.add(crearItem("Abrir...", KeyEvent.VK_O, e -> abrir()));
        mnuArchivo.add(crearItem("Guardar", KeyEvent.VK_S, e -> guardar()));
        mnuArchivo.addSeparator();
        mnuArchivo.add(crearItem("Salir", KeyEvent.VK_Q, e -> System.exit(0)));

        JMenu mnuFormato = new JMenu("Formato");
        JCheckBoxMenuItem itmAjuste = new JCheckBoxMenuItem("Ajuste de línea");
        itmAjuste.addActionListener(e -> {
            areaTexto.setLineWrap(itmAjuste.isSelected());
            areaTexto.setWrapStyleWord(true);
        });
        JMenuItem itmMas = new JMenuItem("Aumentar fuente");
        JMenuItem itmMenos = new JMenuItem("Reducir fuente");
        itmMas.addActionListener(e -> cambiarFuente(+2));
        itmMenos.addActionListener(e -> cambiarFuente(-2));
        mnuFormato.add(itmAjuste);
        mnuFormato.addSeparator();
        mnuFormato.add(itmMas);
        mnuFormato.add(itmMenos);

        JMenuBar barra = new JMenuBar();
        barra.add(mnuArchivo);
        barra.add(mnuFormato);
        return barra;
    }

    private JMenuItem crearItem(String texto, int tecla, ActionListener accion) {
        JMenuItem item = new JMenuItem(texto);
        item.setAccelerator(KeyStroke.getKeyStroke(tecla,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));   // Ctrl + tecla
        item.addActionListener(accion);
        return item;
    }

    private void nuevo() {
        areaTexto.setText("");
        archivoActual = null;
        setTitle("Mini Editor - Sin título");
    }

    private void abrir() {
        JFileChooser selector = new JFileChooser();
        if (selector.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                archivoActual = selector.getSelectedFile();
                areaTexto.setText(Files.readString(archivoActual.toPath()));
                setTitle("Mini Editor - " + archivoActual.getName());
            } catch (IOException ex) {
                mostrarError("No se pudo abrir el archivo: " + ex.getMessage());
            }
        }
    }

    private void guardar() {
        if (archivoActual == null) {
            JFileChooser selector = new JFileChooser();
            if (selector.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
            archivoActual = selector.getSelectedFile();
        }
        try {
            Files.writeString(archivoActual.toPath(), areaTexto.getText());
            setTitle("Mini Editor - " + archivoActual.getName());
        } catch (IOException ex) {
            mostrarError("No se pudo guardar el archivo: " + ex.getMessage());
        }
    }

    private void cambiarFuente(int delta) {
        Font f = areaTexto.getFont();
        areaTexto.setFont(f.deriveFont(f.getSize2D() + delta));
    }

    private void actualizarEstado() {
        lblEstado.setText(" Líneas: " + areaTexto.getLineCount()
                + "    Caracteres: " + areaTexto.getDocument().getLength());
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ej09Editor().setVisible(true));
    }
}
