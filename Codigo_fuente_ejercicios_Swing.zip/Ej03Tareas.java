import javax.swing.*;
import java.awt.*;

public class Ej03Tareas extends JFrame {

    private final DefaultListModel<String> modelo = new DefaultListModel<>();
    private final JList<String> lista = new JList<>(modelo);
    private final JTextField txtTarea = new JTextField();
    private final JLabel lblContador = new JLabel("", SwingConstants.CENTER);

    public Ej03Tareas() {
        super("Lista de tareas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 340);
        setLocationRelativeTo(null);

        JButton btnAgregar = new JButton("Agregar");
        JPanel norte = new JPanel(new BorderLayout(6, 0));
        norte.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        norte.add(txtTarea, BorderLayout.CENTER);
        norte.add(btnAgregar, BorderLayout.EAST);

        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scroll = new JScrollPane(lista);
        scroll.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(10, 10, 5, 10),
                BorderFactory.createTitledBorder("Tareas pendientes")));

        JButton btnCompletar = new JButton("Completar tarea");
        JButton btnVaciar = new JButton("Vaciar lista");
        JPanel botones = new JPanel();
        botones.add(btnCompletar);
        botones.add(btnVaciar);
        JPanel sur = new JPanel(new GridLayout(2, 1));
        sur.add(botones);
        sur.add(lblContador);

        add(norte, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(sur, BorderLayout.SOUTH);

        btnAgregar.addActionListener(e -> agregar());
        txtTarea.addActionListener(e -> agregar());          // Enter en el campo de texto
        btnCompletar.addActionListener(e -> completar());
        btnVaciar.addActionListener(e -> vaciar());
        actualizarContador();
    }

    private void agregar() {
        String texto = txtTarea.getText().trim();
        if (texto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Escriba una tarea antes de agregar.",
                    "Campo vacío", JOptionPane.WARNING_MESSAGE);
            return;
        }
        modelo.addElement(texto);
        txtTarea.setText("");
        txtTarea.requestFocusInWindow();
        actualizarContador();
    }

    private void completar() {
        int indice = lista.getSelectedIndex();
        if (indice < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione una tarea de la lista.");
            return;
        }
        modelo.remove(indice);
        actualizarContador();
    }

    private void vaciar() {
        if (modelo.isEmpty()) return;
        int op = JOptionPane.showConfirmDialog(this, "¿Eliminar todas las tareas?",
                "Confirmar", JOptionPane.YES_NO_OPTION);
        if (op == JOptionPane.YES_OPTION) {
            modelo.clear();
            actualizarContador();
        }
    }

    private void actualizarContador() {
        lblContador.setText("Tareas pendientes: " + modelo.size());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ej03Tareas().setVisible(true));
    }
}
