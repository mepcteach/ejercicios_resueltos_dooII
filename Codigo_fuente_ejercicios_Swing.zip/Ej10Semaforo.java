import javax.swing.*;
import java.awt.*;

public class Ej10Semaforo extends JFrame {

    /** Cada estado conoce su texto, su duración y cuál es el siguiente. */
    private enum Estado {
        ROJO("ROJO - Deténgase", 4),
        VERDE("VERDE - Avance", 4),
        AMARILLO("AMARILLO - Precaución", 2);

        final String texto;
        final int segundos;

        Estado(String texto, int segundos) {
            this.texto = texto;
            this.segundos = segundos;
        }

        Estado siguiente() {
            return switch (this) {
                case ROJO -> VERDE;
                case VERDE -> AMARILLO;
                case AMARILLO -> ROJO;
            };
        }
    }

    /** Panel personalizado: dibuja el semáforo sobreescribiendo paintComponent. */
    private class PanelSemaforo extends JPanel {
        PanelSemaforo() {
            setPreferredSize(new Dimension(180, 290));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(40, 40, 40));
            g2.fillRoundRect(50, 10, 80, 270, 30, 30);
            dibujarLuz(g2, 25, Estado.ROJO, Color.RED, new Color(90, 0, 0));
            dibujarLuz(g2, 110, Estado.AMARILLO, Color.YELLOW, new Color(90, 90, 0));
            dibujarLuz(g2, 195, Estado.VERDE, new Color(0, 220, 0), new Color(0, 70, 0));
            g2.dispose();
        }

        private void dibujarLuz(Graphics2D g2, int y, Estado luz, Color on, Color off) {
            g2.setColor(estado == luz ? on : off);     // enciende solo la luz del estado actual
            g2.fillOval(60, y, 60, 60);
        }
    }

    private Estado estado = Estado.ROJO;
    private int restante = estado.segundos;

    private final PanelSemaforo panel = new PanelSemaforo();
    private final JLabel lblEstado = new JLabel("", SwingConstants.CENTER);
    private final JButton btnIniciar = new JButton("Iniciar");
    private final JButton btnReiniciar = new JButton("Reiniciar");
    private final Timer timer = new Timer(1000, e -> tick());   // dispara cada 1 segundo

    public Ej10Semaforo() {
        super("Semáforo animado");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        lblEstado.setFont(lblEstado.getFont().deriveFont(Font.BOLD, 14f));
        JPanel botones = new JPanel();
        botones.add(btnIniciar);
        botones.add(btnReiniciar);
        JPanel sur = new JPanel(new GridLayout(2, 1));
        sur.add(lblEstado);
        sur.add(botones);

        add(panel, BorderLayout.CENTER);
        add(sur, BorderLayout.SOUTH);

        btnIniciar.addActionListener(e -> alternar());
        btnReiniciar.addActionListener(e -> reiniciar());

        actualizar();
        pack();
        setLocationRelativeTo(null);
    }

    private void alternar() {
        if (timer.isRunning()) {
            timer.stop();
            btnIniciar.setText("Reanudar");
        } else {
            timer.start();
            btnIniciar.setText("Pausar");
        }
    }

    private void reiniciar() {
        timer.stop();
        estado = Estado.ROJO;
        restante = estado.segundos;
        btnIniciar.setText("Iniciar");
        actualizar();
    }

    private void tick() {
        restante--;
        if (restante <= 0) {
            estado = estado.siguiente();
            restante = estado.segundos;
        }
        actualizar();
    }

    private void actualizar() {
        lblEstado.setText(estado.texto + "  (" + restante + " s)");
        panel.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ej10Semaforo().setVisible(true));
    }
}
