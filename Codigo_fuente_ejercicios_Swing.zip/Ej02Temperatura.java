import javax.swing.*;
import java.awt.*;

public class Ej02Temperatura extends JFrame {

    private final JComboBox<String> cboConversion = new JComboBox<>(new String[]{
            "Celsius a Fahrenheit", "Fahrenheit a Celsius",
            "Celsius a Kelvin", "Kelvin a Celsius"});
    private final JTextField txtValor = new JTextField(10);
    private final JLabel lblResultado = new JLabel(" ", SwingConstants.CENTER);

    public Ej02Temperatura() {
        super("Conversor de temperaturas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel formulario = new JPanel(new GridLayout(2, 2, 10, 10));
        formulario.setBorder(BorderFactory.createEmptyBorder(15, 20, 5, 20));
        formulario.add(new JLabel("Conversión:"));
        formulario.add(cboConversion);
        formulario.add(new JLabel("Valor a convertir:"));
        formulario.add(txtValor);

        JButton btnConvertir = new JButton("Convertir");
        JButton btnLimpiar = new JButton("Limpiar");
        btnConvertir.addActionListener(e -> convertir());
        btnLimpiar.addActionListener(e -> {
            txtValor.setText("");
            lblResultado.setText(" ");
            txtValor.requestFocusInWindow();
        });
        JPanel botones = new JPanel();
        botones.add(btnConvertir);
        botones.add(btnLimpiar);

        lblResultado.setFont(lblResultado.getFont().deriveFont(Font.BOLD, 20f));
        lblResultado.setBorder(BorderFactory.createEmptyBorder(5, 20, 15, 20));

        add(formulario, BorderLayout.NORTH);
        add(botones, BorderLayout.CENTER);
        add(lblResultado, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null);
    }

    private boolean bajoCeroAbsoluto(int tipo, double v) {
        return ((tipo == 0 || tipo == 2) && v < -273.15)
                || (tipo == 1 && v < -459.67)
                || (tipo == 3 && v < 0);
    }

    private void convertir() {
        try {
            double v = Double.parseDouble(txtValor.getText().trim().replace(',', '.'));
            int tipo = cboConversion.getSelectedIndex();
            if (bajoCeroAbsoluto(tipo, v)) {
                lblResultado.setForeground(Color.RED);
                lblResultado.setText("Valor bajo el cero absoluto");
                return;
            }
            double r;
            String unidad;
            switch (tipo) {
                case 0 -> { r = v * 9 / 5 + 32;  unidad = "°F"; }
                case 1 -> { r = (v - 32) * 5 / 9; unidad = "°C"; }
                case 2 -> { r = v + 273.15;       unidad = "K"; }
                default -> { r = v - 273.15;      unidad = "°C"; }
            }
            lblResultado.setForeground(new Color(0, 90, 160));
            lblResultado.setText(String.format("%.2f %s", r, unidad));
        } catch (NumberFormatException ex) {
            lblResultado.setForeground(Color.RED);
            lblResultado.setText("Ingrese un número válido");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ej02Temperatura().setVisible(true));
    }
}
