import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

public class Ej05Login extends JFrame {

    private static final String USUARIO = "admin";
    private static final String CLAVE = "1234";
    private static final int MAX_INTENTOS = 3;

    private final JTextField txtUsuario = new JTextField(14);
    private final JPasswordField txtClave = new JPasswordField(14);
    private final JCheckBox chkMostrar = new JCheckBox("Mostrar clave");
    private final JButton btnIngresar = new JButton("Ingresar");
    private final JLabel lblEstado =
            new JLabel("Tiene " + MAX_INTENTOS + " intentos", SwingConstants.CENTER);
    private final char echoOriginal = txtClave.getEchoChar();
    private int intentos = 0;

    public Ej05Login() {
        super("Acceso al sistema");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBorder(BorderFactory.createEmptyBorder(15, 20, 5, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0; form.add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1;                form.add(txtUsuario, gbc);
        gbc.gridx = 0; gbc.gridy = 1; form.add(new JLabel("Contraseña:"), gbc);
        gbc.gridx = 1;                form.add(txtClave, gbc);
        gbc.gridy = 2;                form.add(chkMostrar, gbc);

        JPanel panelBoton = new JPanel();
        panelBoton.add(btnIngresar);
        lblEstado.setBorder(BorderFactory.createEmptyBorder(0, 10, 15, 10));

        add(form, BorderLayout.NORTH);
        add(panelBoton, BorderLayout.CENTER);
        add(lblEstado, BorderLayout.SOUTH);

        btnIngresar.addActionListener(e -> ingresar());
        txtClave.addActionListener(e -> ingresar());          // Enter en la contraseña
        chkMostrar.addActionListener(e ->
                txtClave.setEchoChar(chkMostrar.isSelected() ? (char) 0 : echoOriginal));

        setSize(400, 270);
        setLocationRelativeTo(null);
    }

    private void ingresar() {
        String usuario = txtUsuario.getText().trim();
        char[] clave = txtClave.getPassword();
        boolean valido = usuario.equals(USUARIO) && new String(clave).equals(CLAVE);
        Arrays.fill(clave, '0');            // buena práctica: no dejar la clave en memoria

        if (valido) {
            JOptionPane.showMessageDialog(this, "¡Bienvenido, " + usuario + "!",
                    "Acceso concedido", JOptionPane.INFORMATION_MESSAGE);
            dispose();                      // aquí se abriría la ventana principal
            return;
        }

        intentos++;
        int restantes = MAX_INTENTOS - intentos;
        lblEstado.setForeground(Color.RED);
        if (restantes <= 0) {
            lblEstado.setText("Cuenta bloqueada por demasiados intentos");
            btnIngresar.setEnabled(false);
            txtUsuario.setEnabled(false);
            txtClave.setEnabled(false);
        } else {
            lblEstado.setText("Credenciales incorrectas. Intentos restantes: " + restantes);
            txtClave.setText("");
            txtClave.requestFocusInWindow();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ej05Login().setVisible(true));
    }
}
