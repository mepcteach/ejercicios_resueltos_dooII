import javax.swing.*;
import java.awt.*;

public class Ej06Pizzeria extends JFrame {

    private static final String[] TAMANOS = {"Pequeña", "Mediana", "Familiar"};
    private static final int[] PRECIO_TAMANO = {5000, 8000, 12000};
    private static final String[] EXTRAS = {"Queso extra", "Champiñones", "Aceitunas", "Tocino"};
    private static final int[] PRECIO_EXTRA = {1500, 1200, 1000, 1800};

    private final JRadioButton[] radios = new JRadioButton[TAMANOS.length];
    private final JCheckBox[] checks = new JCheckBox[EXTRAS.length];
    private final JSpinner spnCantidad = new JSpinner(new SpinnerNumberModel(1, 1, 20, 1));
    private final JTextArea txtBoleta = new JTextArea(12, 34);

    public Ej06Pizzeria() {
        super("Pizzería Don Luigi - Pedido");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // --- Panel de tamaños (RadioButton: solo uno seleccionado) ---
        JPanel pnlTamano = new JPanel(new GridLayout(0, 1));
        pnlTamano.setBorder(BorderFactory.createTitledBorder("Tamaño"));
        ButtonGroup grupo = new ButtonGroup();
        for (int i = 0; i < TAMANOS.length; i++) {
            radios[i] = new JRadioButton(TAMANOS[i] + "  ($" + PRECIO_TAMANO[i] + ")");
            grupo.add(radios[i]);
            pnlTamano.add(radios[i]);
        }
        radios[0].setSelected(true);

        // --- Panel de extras (CheckBox: varios a la vez) ---
        JPanel pnlExtras = new JPanel(new GridLayout(0, 1));
        pnlExtras.setBorder(BorderFactory.createTitledBorder("Ingredientes extra"));
        for (int i = 0; i < EXTRAS.length; i++) {
            checks[i] = new JCheckBox(EXTRAS[i] + "  (+$" + PRECIO_EXTRA[i] + ")");
            pnlExtras.add(checks[i]);
        }

        JPanel pnlCantidad = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlCantidad.setBorder(BorderFactory.createTitledBorder("Cantidad"));
        pnlCantidad.add(spnCantidad);

        JPanel izquierda = new JPanel(new BorderLayout());
        izquierda.add(pnlTamano, BorderLayout.NORTH);
        JPanel centroIzq = new JPanel(new BorderLayout());
        centroIzq.add(pnlExtras, BorderLayout.NORTH);
        centroIzq.add(pnlCantidad, BorderLayout.CENTER);
        izquierda.add(centroIzq, BorderLayout.CENTER);

        txtBoleta.setEditable(false);
        txtBoleta.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        JScrollPane scroll = new JScrollPane(txtBoleta);
        scroll.setBorder(BorderFactory.createTitledBorder("Boleta"));

        JButton btnCalcular = new JButton("Calcular total");
        JButton btnNuevo = new JButton("Nuevo pedido");
        JPanel botones = new JPanel();
        botones.add(btnCalcular);
        botones.add(btnNuevo);

        add(izquierda, BorderLayout.WEST);
        add(scroll, BorderLayout.CENTER);
        add(botones, BorderLayout.SOUTH);

        btnCalcular.addActionListener(e -> calcular());
        btnNuevo.addActionListener(e -> nuevoPedido());

        pack();
        setLocationRelativeTo(null);
    }

    private String dinero(int monto) {
        return "$" + String.format("%,d", monto).replace(',', '.');
    }

    private void calcular() {
        int tamano = 0;
        for (int i = 0; i < radios.length; i++) {
            if (radios[i].isSelected()) tamano = i;
        }
        int unitario = PRECIO_TAMANO[tamano];

        StringBuilder sb = new StringBuilder();
        sb.append("      BOLETA DE PEDIDO\n");
        sb.append("------------------------------\n");
        sb.append(String.format("Pizza %-10s %10s%n", TAMANOS[tamano], dinero(unitario)));
        for (int i = 0; i < checks.length; i++) {
            if (checks[i].isSelected()) {
                unitario += PRECIO_EXTRA[i];
                sb.append(String.format("  + %-11s %10s%n", EXTRAS[i], dinero(PRECIO_EXTRA[i])));
            }
        }
        int cantidad = (int) spnCantidad.getValue();
        int total = unitario * cantidad;
        long iva = total - Math.round(total / 1.19);

        sb.append("------------------------------\n");
        sb.append(String.format("Precio unitario:  %10s%n", dinero(unitario)));
        sb.append(String.format("Cantidad:         %10d%n", cantidad));
        sb.append(String.format("IVA incluido:     %10s%n", dinero((int) iva)));
        sb.append(String.format("TOTAL A PAGAR:    %10s%n", dinero(total)));
        txtBoleta.setText(sb.toString());
    }

    private void nuevoPedido() {
        radios[0].setSelected(true);
        for (JCheckBox chk : checks) chk.setSelected(false);
        spnCantidad.setValue(1);
        txtBoleta.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ej06Pizzeria().setVisible(true));
    }
}
