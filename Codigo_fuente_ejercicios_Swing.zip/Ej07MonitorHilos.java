import javax.swing.*;
import java.awt.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Ej07MonitorHilos extends JFrame {

    private static final DateTimeFormatter HORA = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final String[] CAMARAS = {"Cámara Frutas", "Cámara Verduras", "Cámara Lácteos"};

    private final JTextArea txtMonitor = new JTextArea(14, 72);
    private final JLabel lblEstado = new JLabel("Estado: DETENIDO");
    private final JLabel lblEventos = new JLabel("Eventos: 0");
    private final JButton btnIniciar = new JButton("Iniciar monitoreo");
    private final JButton btnDetener = new JButton("Detener");
    private final JButton btnLimpiar = new JButton("Limpiar");

    private final List<Thread> sensores = new ArrayList<>();
    private final Object cerrojo = new Object();   // objeto "monitor" que protege la sección crítica
    private int totalEventos = 0;                  // recurso compartido entre los hilos

    public Ej07MonitorHilos() {
        super("Monitor de hilos - Cámaras de frío");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        txtMonitor.setEditable(false);
        txtMonitor.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        txtMonitor.setBackground(Color.BLACK);
        txtMonitor.setForeground(new Color(0, 230, 0));

        JPanel barra = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        barra.add(btnIniciar);
        barra.add(btnDetener);
        barra.add(btnLimpiar);

        JPanel estado = new JPanel(new BorderLayout());
        estado.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));
        estado.add(lblEstado, BorderLayout.WEST);
        estado.add(lblEventos, BorderLayout.EAST);

        add(barra, BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(txtMonitor,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        add(scroll, BorderLayout.CENTER);
        add(estado, BorderLayout.SOUTH);

        btnDetener.setEnabled(false);
        btnIniciar.addActionListener(e -> iniciar());
        btnDetener.addActionListener(e -> detener());
        btnLimpiar.addActionListener(e -> txtMonitor.setText(""));

        pack();
        setLocationRelativeTo(null);
    }

    /** Sección crítica: solo un hilo a la vez puede ejecutar el bloque synchronized. */
    private void registrar(String mensaje, boolean esLectura) {
        synchronized (cerrojo) {
            if (esLectura) {
                totalEventos++;
            }
            String linea = LocalTime.now().format(HORA) + "  " + mensaje + "\n";
            int total = totalEventos;
            // Swing NO es thread-safe: la actualización visual se delega al hilo de eventos (EDT)
            SwingUtilities.invokeLater(() -> {
                txtMonitor.append(linea);
                txtMonitor.setCaretPosition(txtMonitor.getDocument().getLength()); // auto-scroll
                lblEventos.setText("Eventos: " + total);
            });
        }
    }

    private void iniciar() {
        registrar("Monitoreo INICIADO con " + CAMARAS.length + " hilos", false);
        for (String camara : CAMARAS) {
            Thread hilo = new Thread(() -> {
                Random azar = new Random();
                while (!Thread.currentThread().isInterrupted()) {
                    double temp = 2 + azar.nextDouble() * 8;              // entre 2,0 y 10,0 °C
                    String alerta = temp > 8 ? "  <-- ALERTA: temperatura alta" : "";
                    registrar(String.format("%-16s %4.1f °C%s", camara, temp, alerta), true);
                    try {
                        Thread.sleep(500 + azar.nextInt(1000));           // espera de 0,5 a 1,5 s
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();               // termina el while
                    }
                }
            }, "Sensor-" + camara);
            hilo.setDaemon(true);
            sensores.add(hilo);
            hilo.start();
        }
        lblEstado.setText("Estado: ACTIVO (" + CAMARAS.length + " hilos)");
        btnIniciar.setEnabled(false);
        btnDetener.setEnabled(true);
    }

    private void detener() {
        for (Thread hilo : sensores) {
            hilo.interrupt();                    // pide a cada hilo que termine
        }
        sensores.clear();
        registrar("Monitoreo DETENIDO", false);
        lblEstado.setText("Estado: DETENIDO");
        btnIniciar.setEnabled(true);
        btnDetener.setEnabled(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ej07MonitorHilos().setVisible(true));
    }
}
