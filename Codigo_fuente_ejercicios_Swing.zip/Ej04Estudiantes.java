import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Ej04Estudiantes extends JFrame {

    private final JTextField txtNombre = new JTextField(12);
    private final JComboBox<String> cboCarrera = new JComboBox<>(
            new String[]{"Informática", "Enfermería", "Contabilidad", "Diseño"});
    private final JSpinner spnNota = new JSpinner(new SpinnerNumberModel(4.0, 1.0, 7.0, 0.1));
    private final DefaultTableModel modelo = new DefaultTableModel(
            new String[]{"Nombre", "Carrera", "Nota"}, 0) {
        @Override
        public boolean isCellEditable(int fila, int columna) {
            return false;                       // la tabla es solo de lectura
        }
    };
    private final JTable tabla = new JTable(modelo);
    private final JLabel lblPromedio = new JLabel();

    public Ej04Estudiantes() {
        super("Registro de notas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(560, 380);
        setLocationRelativeTo(null);

        JPanel formulario = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 10));
        formulario.add(new JLabel("Nombre:"));
        formulario.add(txtNombre);
        formulario.add(new JLabel("Carrera:"));
        formulario.add(cboCarrera);
        formulario.add(new JLabel("Nota:"));
        spnNota.setPreferredSize(new Dimension(65, 24));
        formulario.add(spnNota);

        JButton btnAgregar = new JButton("Agregar");
        JButton btnEliminar = new JButton("Eliminar seleccionado");
        JPanel sur = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        sur.add(btnAgregar);
        sur.add(btnEliminar);
        sur.add(lblPromedio);

        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(22);

        add(formulario, BorderLayout.NORTH);
        add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(sur, BorderLayout.SOUTH);

        btnAgregar.addActionListener(e -> agregar());
        btnEliminar.addActionListener(e -> eliminar());
        actualizarPromedio();
    }

    private void agregar() {
        String nombre = txtNombre.getText().trim();
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio.",
                    "Validación", JOptionPane.WARNING_MESSAGE);
            return;
        }
        double nota = Math.round(((Double) spnNota.getValue()) * 10) / 10.0;
        modelo.addRow(new Object[]{nombre, cboCarrera.getSelectedItem(), nota});
        txtNombre.setText("");
        txtNombre.requestFocusInWindow();
        actualizarPromedio();
    }

    private void eliminar() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione una fila de la tabla.");
            return;
        }
        modelo.removeRow(fila);
        actualizarPromedio();
    }

    private void actualizarPromedio() {
        int n = modelo.getRowCount();
        double suma = 0;
        for (int i = 0; i < n; i++) {
            suma += (Double) modelo.getValueAt(i, 2);
        }
        String promedio = (n == 0) ? "-" : String.format("%.1f", suma / n);
        lblPromedio.setText("Estudiantes: " + n + "   |   Promedio: " + promedio);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ej04Estudiantes().setVisible(true));
    }
}
