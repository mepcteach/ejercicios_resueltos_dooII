import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class Ej08Adivina extends JFrame {

    private static final int MAX_INTENTOS = 7;

    private final Random azar = new Random();
    private int secreto;
    private int intentos;

    private final JLabel lblPista = new JLabel("", SwingConstants.CENTER);
    private final JSpinner spnNumero = new JSpinner(new SpinnerNumberModel(50, 1, 100, 1));
    private final JButton btnProbar = new JButton("Probar");
    private final JButton btnNuevo = new JButton("Nuevo juego");
    private final JProgressBar barra = new JProgressBar(0, MAX_INTENTOS);

    public Ej08Adivina() {
        super("Adivina el número");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        lblPista.setFont(lblPista.getFont().deriveFont(Font.BOLD, 15f));
        lblPista.setBorder(BorderFactory.createEmptyBorder(15, 10, 5, 10));

        JPanel fila1 = new JPanel();
        fila1.add(new JLabel("Su número:"));
        fila1.add(spnNumero);
        fila1.add(btnProbar);

        barra.setStringPainted(true);
        JPanel fila2 = new JPanel(new BorderLayout());
        fila2.setBorder(BorderFactory.createEmptyBorder(5, 30, 5, 30));
        fila2.add(barra, BorderLayout.CENTER);

        JPanel fila3 = new JPanel();
        fila3.add(btnNuevo);

        JPanel centro = new JPanel(new GridLayout(3, 1));
        centro.add(fila1);
        centro.add(fila2);
        centro.add(fila3);

        add(lblPista, BorderLayout.NORTH);
        add(centro, BorderLayout.CENTER);

        btnProbar.addActionListener(e -> probar());
        btnNuevo.addActionListener(e -> nuevoJuego());

        nuevoJuego();
        setSize(380, 240);
        setLocationRelativeTo(null);
    }

    private void nuevoJuego() {
        secreto = azar.nextInt(100) + 1;          // número entre 1 y 100
        intentos = 0;
        barra.setValue(0);
        barra.setString("Intentos: 0 / " + MAX_INTENTOS);
        lblPista.setForeground(UIManager.getColor("Label.foreground"));
        lblPista.setText("Adivine el número entre 1 y 100");
        spnNumero.setEnabled(true);
        btnProbar.setEnabled(true);
    }

    private void probar() {
        int n = (int) spnNumero.getValue();
        intentos++;
        barra.setValue(intentos);
        barra.setString("Intentos: " + intentos + " / " + MAX_INTENTOS);

        if (n == secreto) {
            terminar("¡Correcto! Lo logró en " + intentos + " intentos", new Color(0, 140, 0));
        } else if (intentos >= MAX_INTENTOS) {
            terminar("Perdió. El número era " + secreto, Color.RED);
        } else {
            lblPista.setText(n < secreto ? "El número es MAYOR que " + n
                                         : "El número es MENOR que " + n);
        }
    }

    private void terminar(String mensaje, Color color) {
        lblPista.setForeground(color);
        lblPista.setText(mensaje);
        spnNumero.setEnabled(false);
        btnProbar.setEnabled(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ej08Adivina().setVisible(true));
    }
}
